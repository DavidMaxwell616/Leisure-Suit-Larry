--------------------------------------------------------------------
FishWings	version 0.86
--------------------------------------------------------------------

A program for viewing and managing files on Apple II disk images.

--------------------------------------------------------------------
Installation
--------------------------------------------------------------------
To install FishWings copy the following files to any folder.

ReadMe.txt
A2 font readme.txt
FishWings.exe
FISHWINGS.HLP
FWPRO.DSK
FWDOS.DSK

If you are installing FishWings over an older version, first delete the old "FishWings.ini" file.  Your old settings will be lost.

The A2LIKE.TTF (font) should be installed in your Windows\Fonts folder.

To use FishWings you must read and agree to the following:

--------------------------------------------------------------------
License
--------------------------------------------------------------------

FishWings version 0.86 is a licensed, copyrighted, program that is free.  Other versions of FishWings may or may not be free.  You are licensed to use, copy and distribute this version of FishWings as long as you read and agree to the following:

I, Charlie Danemark, am the author and copyright holder of FishWings.
 
FishWings is distributed "AS IS".  

Although, I hope you will find FishWings useful, it is not guaranteed to do anything. 

FishWings is not guaranteed to be free of defects or bugs.

I cannot be held responsible for any direct or indirect damages caused by FishWings. 

When distributing FishWings all the accompanying files (including this license agreement) must be included.

You may not alter FishWings without my written permission.

Using FishWings means that you agree with this license.

If you do not agree with the terms of this license you must delete all FishWings files from your computer.
