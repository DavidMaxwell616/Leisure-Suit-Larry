A2Like TrueType font (A2Like.ttf) is included with FishWings.  To use it you must install it in your Windows\Fonts folder.  In FishWings set the "Preferences-Display Window-Font-Apple" radio button.

A2Like is an Apple //e 80 column text "look-a-like" Truetype font.

A2Like scales poorly.  It only looks good (on the screen) at sizes that are multiples of 12.
Other sizes will look bad on the screen but will print reasonably well.

Mousetext characters can be found at ASCII $C0/192 through $DF/223.  This is the so called "running man" set.  The alternate set is at ASCII $E0/224 through $FF/255.

Within FishWings (or for that matter most any Windows word processor) you can key in a mousetext character by holding down the "Alt" key while typing in the ASCII number of the character you want.
For instance, holding down the "Alt" key while typing 0192 (must be 4 decimal digits) will display the "solid apple" symbol.




